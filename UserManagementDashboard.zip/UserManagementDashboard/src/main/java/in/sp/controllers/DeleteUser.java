package in.sp.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import in.sp.dbcon.DbConnection;

@WebServlet("/deleteUser")
public class DeleteUser extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("email");

        try {
            Connection con = DbConnection.getConnection();
            String deleteQuery = "DELETE FROM register WHERE email=?";
            PreparedStatement ps = con.prepareStatement(deleteQuery);
            ps.setString(1, email);

            int count = ps.executeUpdate();
            if(count > 0){
                response.sendRedirect("dashboard.jsp"); // refresh dashboard
            } else {
                response.getWriter().println("Failed to delete user.");
            }

            ps.close();
            con.close();
        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
