package in.sp.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import in.sp.dbcon.DbConnection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/regForm")
public class Register extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String myname = request.getParameter("name1");
        String myemail = request.getParameter("email1");
        String mypass = request.getParameter("pass1");
        String mycity = request.getParameter("city1");

        try {
            Connection con = DbConnection.getConnection();

            
            String checkQuery = "SELECT * FROM register WHERE name=? OR email=?";
            PreparedStatement psCheck = con.prepareStatement(checkQuery);
            psCheck.setString(1, myname);
            psCheck.setString(2, myemail);
            ResultSet rs = psCheck.executeQuery();

            if (rs.next()) {
               
                out.println("<h3 style='color:red'>Name or Email already exists. Try another.</h3>");
                RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
                rd.include(request, response);
            } else {
                
                String insertQuery = "INSERT INTO register(name, email, password, city) VALUES(?,?,?,?)";
                PreparedStatement psInsert = con.prepareStatement(insertQuery);
                psInsert.setString(1, myname);
                psInsert.setString(2, myemail);
                psInsert.setString(3, mypass);
                psInsert.setString(4, mycity);

                int count = psInsert.executeUpdate();
                if (count > 0) {
                    out.println("<h3 style='color:green'>Registered Successfully! You can now login.</h3>");
                    RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                    rd.include(request, response);
                } else {
                    out.println("<h3 style='color:red'>Registration failed. Try again.</h3>");
                    RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
                    rd.include(request, response);
                }
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3 style='color:red'>Error occurred during registration.</h3>");
            RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
            rd.include(request, response);
        }
    }
}
